<?php 
include '../config/koneksi.php';
include '../library/oop.php';

error_reporting(0);
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../admin'</script>";
}
$perintah = new oop();
@$field ="kd_kategori = '$_POST[kd_kategori]', kategori = '$_POST[kategori]'";
$table= 'kategori';
$redirect="kategori.php";
$where = "kd_kategori = '$_GET[id]'";

if (isset($_POST['simpan'])) {
  $perintah->simpan($con , $table , $field , $redirect);
}
if (isset($_GET['hapus'])) {
  $perintah->hapus($con , $table , $where , $redirect);
}                                        
if (isset($_GET['edit'])) {
  $edit = $perintah->edit($con , $table, $field ,$where);
}
if (isset($_POST['ubah'])) {
  $data = "kategori = '$_POST[kategori]'";
  $perintah->ubah($con , $table , $data , $where , $redirect);
}                                                                       
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Eithree Shop</title> 

    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
	  <link href="../css/style.css" rel="stylesheet">
	  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
	  </head>
<body>
  <header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../admin/admin.php">Home</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/kategori.php">Input Kategori</a></li>
                                            <li><a href="../admin/barang.php">Input Barang</a></li>
                                            
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Laporan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/laporan_kategori.php">Laporan Kategori</a></li>
                                            <li><a href="../admin/laporan_barang.php">Laporan Barang</a></li>
                                            
                                            
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pelanggan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/resi.php">Resi Pelanggan</a></li>
                                            <li><a href="../admin/testimoni.php">Testimoni Pelanggan</a></li>
                                            <li><a href="../admin/daftar_beli.php">Barang Pelanggan</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('Yakin mau keluar?')">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
	<div id="wrapper">
	
		<div class="container">

      <!-- start: Table -->
      <form method="post">
        
                 <div class="table-responsive">
                 <div class="title"><h3>Data Barang Pembeli</h3></div>
             <table align="right">
            <tr>
              <td></td>
              <td><input type="text" name="tcari" placeholder="cari"></td>
              <td></td>
              <td><input style="margin-top: -10px" class="btn btn-success btn-lg" type="submit" name="cari" value="CARI"></td>
            </tr>
              </table>
      </form>
                 <div class="container">
                 <div class="row"><br>
                   <table class="table table-striped  table-condensed table-resposive">
                     <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>No Telpon</th>
                    <th>Kode Penjualan</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Harga Satuan</th>
                    <th>Total</th>
                    <th>Status</th>
                    
                     <?php 
                     if (isset($_POST['cari'])) {
                    $sql = "SELECT * FROM q_data WHERE nama like '%$_POST[tcari]%' or jumlah like '%$_POST[tcari]%' or kode_penjualan like '%$_POST[tcari]%' or nama_barang like '%$_POST[tcari]%' or harga_barang like '%$_POST[tcari]%' or total like '%$_POST[tcari]%' or status like '%$_POST[tcari]%' or alamat like '%$_POST[tcari]%' or telpon like '$_POST[tcari]'";
                     }else{ 
                     $sql = "SELECT * FROM q_data";
                     }
                     $query = mysqli_query($con, $sql);
                     $no = 1;
                     while ($field = mysqli_fetch_array($query)) {
                       
                      ?>
                      </tr>
                     <tr>
                       <td><?php echo $no++ ?></td>
                       <td><?php echo $field['nama']; ?></td>
                       <td><?php echo $field['alamat']; ?></td>
                       <td><?php echo $field['telpon']; ?></td>
                       <td><?php echo $field['kode_penjualan']; ?></td>
                       <td><?php echo $field['nama_barang']; ?></td>
                       <td><?php echo $field['jumlah']; ?></td>
                       <td><?php echo $field['harga_barang']; ?></td>
                       <td><?php echo $field['total']; ?></td>
                       <td><?php echo $field['status']; ?></td>
                     </tr>
                     <?php 
                   }
                      ?>
                   </table>
                 </div>
               </div>

             </div>
         </div>
    </div>
				<div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script def src="../js/custom.js"></script>

<script src="jquery.validate.js"></script>
</body>
</html>