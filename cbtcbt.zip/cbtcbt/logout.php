<?php 
session_destroy(0);
header('Location:login.php');
 ?>