<?php
class oop{
	function ngambil($con , $table , $field){
		$sql = "SELECT * FROM $table ";
		
	}
	function autokode($con , $table , $field , $prefix){
		$sql = "SELECT COUNT($field) FROM $table";
		$query = mysqli_query($con , $sql);
		$rows = mysqli_num_rows($query);
		if($rows > 0 ) {
			$sql = "SELECT MAX($field) AS max from $table";
			$query = mysqli_query($con , $sql);
			$result = mysqli_fetch_array($query);
			$jml = substr($result['max'], 2,3);
			$jml += 1;
			if (strlen($jml)==4) {
				$kode = $prefix.$jml;
			}elseif (strlen($jml)==3) {
				$kode = $prefix."0".$jml;
			}elseif (strlen($jml)==2) {
				$kode = $prefix."00".$jml;
			}elseif (strlen($jml)==1) {
				$kode = $prefix."000".$jml;
			}
		}else{
			$kode = $prefix.'0001';
		} return $kode;
	}
	function simpan($con , $table , $field, $redirect){
		$sql = "INSERT INTO $table SET $field";
		$query = mysqli_query($con, $sql);
		if ($query) {
			echo "<script>alert('berhasil');document.location.href='$redirect'</script>";
			}else{
			echo "<script>alert('gagal');document.location.href='$redirect'</script>";
			
			}
	}
        function logout(){
			@session_destroy();
			echo "<script>alert('keluar');window.location.href='index.php'</script>";
		}
	function simpankart($con , $table ,array $field, $redirect){
		$sql = "INSERT INTO $table SET ($field)";
		$query = mysqli_query($con, $sql);
		if ($query) {
			echo "<script>alert('berhasil');document.location.href='$redirect'</script>";
			}else{
			echo "<script>alert('gagal');document.location.href='$redirect'</script>";
			
			}
	}
	function tampil($con , $table){
		$sql = "SELECT * FROM $table";
		$query = mysqli_query($con ,$sql);
		$isi = [];
		while ($data = mysqli_fetch_array($query)) 
			$isi[]= $data;
			return $isi;
	}
	function hapus($con , $table ,$where , $redirect){
		$sql = "DELETE FROM $table WHERE $where";
		$query = mysqli_query($con , $sql);
		if ($query) {
			echo "<script>alert('sukses');document.location.href='$redirect'</script>";
		}else{
			echo "<script>alert('gagal');document.location.href='$redirect'</script>";
		}
	}
	function edit($con , $table, $field ,$where){
		$sql = "SELECT * FROM $table WHERE $where";
		$query = mysqli_query($con , $sql);
		$field = mysqli_fetch_array($query);
		return $field;
	}
	function ubah($con , $table , $field , $where , $redirect){
		$sql = "UPDATE $table SET $field WHERE $where";
		$query = mysqli_query($con ,$sql);
		if ($query) {
			# code...
			echo "<script>alert('sukses');document.location.href='$redirect'</script>";
		}else{
			echo "<script>alert('gagal');document.location.href='$redirect'</script>";
		}

	}
	function login($con , $table , $username , $password , $form){
		@session_start();
		@$sql = "SELECT * FROM $table WHERE username = '$username' and password = '$password'";
		@$query = mysqli_query($con , $sql);
		@$tampil = mysqli_fetch_array($query);
		@$cek = mysqli_num_rows($query);
		if ($query) {
			$_SESSION['username'] = $username AND $_SESSION['password'] = $password;
			echo "<script>alert('berhasil');document.location.href='$form'</script>";
		}else{
            ?>
              <script>alert("gagal");history.go(-1);</script>
            <?php
		}
	}
	function daftar($con, $table, $isi,$form){
        $sql = "INSERT INTO $table SET $isi";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
                    alert('Pendaftaran Berhasil');
                    document.location.href='$form'
                  </script>";
        }else{
            echo "<script>
                    alert('Pendaftaran Gagal');
                    document.location.href='daftar.php'
                  </script>";
        }
    }
    function simpann($con, $table, $field,$redirect){
        $sql = "INSERT INTO $table SET $field";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
                    alert('Success');
                    document.location.href='$redirect'
                  </script>";
        }else{
            echo "<script>
                    alert('Failed');
                    document.location.href='$redirect'
                  </script>";
        }
    }
        public function autokode1($table,$field,$pre){
            global $con;
            $sqlc   = "SELECT COUNT($field) as jumlah FROM $table";
            $querys = mysqli_query($con,$sqlc);
            $number = mysqli_fetch_assoc($querys);
            if($number['jumlah'] > 0){
                $sql    = "SELECT MAX($field) as kode FROM $table";
                $query  = mysqli_query($con,$sql);
                $number = mysqli_fetch_assoc($query);
                $strnum = substr($number['kode'], 2,3);
                $strnum = $strnum + 1;
                if(strlen($strnum) == 3){ 
                    $kode = $pre.$strnum;
                }else if(strlen($strnum) == 2){ 
                    $kode = $pre."0".$strnum;
                }else if(strlen($strnum) == 1){ 
                    $kode = $pre."00".$strnum;
                }
            }else{
                $kode = $pre."001";
            }

            return $kode;
        }

}
?>