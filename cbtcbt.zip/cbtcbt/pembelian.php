<?php 
include 'config/koneksi.php';
?>

<h1>Laporan data pembelian</h1>
<table border="1">
	<tr>
		<td>kode kategori</td>
		<td>kategori</td>
		<td>kode barang</td>
		<td>nama barang</td>
		<td>harga</td>
		<td>stok</td>
	</tr>
	<?php 
	$no = 0;
	$sql = mysqli_query($con , "SELECT * FROM q_barang ORDER BY kd_kategori ASC");
	while ($data = mysqli_fetch_assoc($sql)) {
		# code...
		$no++
	?>
	<tr>
		<td><?php echo @$no ?></td>
		<td><?php echo @$data[kd_kategori] ?></td>
		<td><?php echo @$data[kategori] ?></td>
		<td><?php echo @$data[kd_barang] ?></td>
		<td><?php echo @$data[nama_barang] ?></td>
		<td><?php echo @$data[harga_barang] ?></td>
		<td><?php echo @$data[stok] ?></td>
	</tr>
	<?php } ?>
	</table>