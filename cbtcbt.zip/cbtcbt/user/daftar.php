<?php  
include '../config/koneksi.php';

if (isset($_POST['simpan'])) {
  
  $sql = "INSERT INTO user SET  nama = '$_POST[nama]', email = '$_POST[email]', username = '$_POST[username]' , password = '$_POST[password]' , alamat ='$_POST[alamat]' , telpon = '$_POST[notelp]'";
  $query = mysqli_query($con , $sql);
  if ($query) {
      echo"<script>alert('berhasil');document.location.href='../user/login.php'</script>";
    }else{
      echo "<script>alert('berhasil');document.location.href='../user/daftar.php'</script>";
    }
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registrasi</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body background="../gambar/a.jpg">
    <form method="post">
	<div class="container" >
    <div class="row"><br>
      <br>
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <div class="panel panel-default">
          <div class="panel-body">
              <h1><center >R E G I S T R A S I</center></h1>
              <hr>
              <div class="form-group">
                <label>Nama lengkap</label>
                <input type="text" name="nama" class="form-control" required >
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required >
              </div>
              <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required >
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required >
              </div>
              <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" required >
              </div>
              <div class="form-group">
                <label>No Telpon</label>
                <input type="number" name="notelp" class="form-control" required >
              </div>
              
              <div class="form-group">
                <button class="btn  btn-primary" name="simpan">Registrasi</button>
                <a href="login.php">kembali</a>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../assets/js/bootstrap.min.js"></script>
  </body>
</html>