<?php 
include '../config/koneksi.php';
include '../library/oop.php';
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../user/login.php'</script>";
 }
 $perintah = new oop();
	
    @$foto = $perintah->tampil($con,"bukti WHERE kode_penjualan='$data[kode_penjualan]'");
    foreach ($foto as $foto) {
    	$f = $foto['gambar'];
    }
    $status = "";	
 if (isset($_POST['upload'])) {
            @$nama_file = $_FILES['gambar']['name'];
            @$tmp_file = $_FILES['gambar']['tmp_name'];
            $redirect = "bukti.php?kode_penjualan=$_GET[kode_penjualan]";
            move_uploaded_file($tmp_file, "../gambar/struk/$nama_file");
            $field = "kode_penjualan='$_GET[kode_penjualan]',id_user='$_SESSION[id]', gambar='$nama_file'";
             $sql = "insert into bukti set kode_penjualan='$_GET[kode_penjualan]',id_user='$_SESSION[id]', gambar='$nama_file' ";
             $query = mysqli_query($con , $sql);
            if ($query) {
                 echo "<script>
                    alert('berhasil');
                    document.location.href='$redirect'
                  </script>";
            }else{
                echo mysqli_error($con);
            }
        }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>EithreeShop</title> 
	<meta name="description" content="Distro, cikarang, terlengkap, information, technology, jababeka, baru, murah"/>
	<meta name="keywords" content="Kaos, Murah, Cikarang, Baru, terlengkap, harga, terjangkau" />
	<meta name="author" content="Hakko Bio Richard"/>
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: Facebook Open Graph -->
	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>
	<!-- end: Facebook Open Graph -->

    <!-- start: CSS --> 
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
	<!-- end: CSS -->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
    
	<!--start: Header -->
<header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../user/halaman.php">Beranda</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>

                                    <li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Struk<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' GROUP BY `kode_penjualan`"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="bukti.php?kode_penjualan=<?php echo $field['kode_penjualan'] ?>"><?php echo $field['kode_penjualan']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('apa anda yakin?')" name="logout">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
    
    <!--end: Header-->
	
	<!--start: Wrapper-->
	<div id="wrapper">
				
				<form method="post">
					
		<!-- start: Container -->
		<div class="container">
			<?php 
			$sql = "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = $_GET[kode_penjualan]";
			$queryy = mysqli_query($con , $sql);
			 ?>
			<h3>Pembelian : <?php echo @$_GET['kode_penjualan']; ?></h3>
			<!-- start: Table -->
                 <div class="table-responsive">
                 <div class="title"><h3>Form Checkout</h3></div>
                 <div class="container">
				<table class="table table-hover table-condensed">
				<tr>
                    <th><center>Kode Barang</center></th>
					<th><center>Nama Barang</center></th>
					<th><center>Jumlah</center></th>
					<th><center>Harga Satuan</center></th>
					<th><center>Sub Total</center></th>
					<th><center>Status</center></th>
				</tr>

                
 			    <?php
 			    $total = 0;
            @$query = mysqli_query($con, "select * from tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '$_GET[kode_penjualan]' ORDER BY status ASC");
            while ($data = mysqli_fetch_array($query)){
            $subtotal = $data['jumlah']*$data['harga_barang'];
            $total = $total + $subtotal;
            $sql=mysqli_query($con, "UPDATE tbl_penjualan SET total = '$subtotal' WHERE id_user = '$_SESSION[id]'");
            ?>
                <tr>
                <td><center><?php echo $data['kd_barang']; ?></center></td>
                <td><center><?php echo $data['nama_barang']; ?></center></td>
                <td><center><?php echo $data['jumlah']; ?></center></td>
                <td><center><?php echo "Rp.".number_format($data['harga_barang'],2,",","."); ?></center></td>
                <td><center><?php $subtotal = $data['jumlah']*$data['harga_barang'];  echo "Rp.".number_format($subtotal,2,",","."); ?></center></td>
                <td><center><?php echo $data['status']; ?></center></td>
                <td>
                	<style type="text/css">
                		.overlay{
     position: fixed;
     top :0;
     bottom: 0;
     left: 0;
     right: 0;
     background-color: rgba(0 , 0, 0, 0.7);        
     transition: opacity 500ms;
     visibility: hidden;
     opacity: 0;
}
.overlay:target{
        visibility: visible;
        opacity: 1;
}
.popup{
        margin: 70px auto;
        padding: 20px;
        background: #fff;
        border-radius: 5px;
        width: 40%;
        position: relative;
        transition: all 5s ease-in-out;
}
.popup .close{
       position: absolute;
       top: 20px;
       right: 30px;
       transition: all 200ms;
       font-size: 30px;
       font-weight: bold;
       text-decoration: none;
       color : grey;       
}
.popup .close:hover{
        color: red;
}
.popup .content{
        max-height: 40%;
        overflow: auto;
}
@media screen and (max-width: 700px;){
        .popup{
                width: 60%;

        }
}
                	</style>
                </td>
                </tr>
                <?php 	}?>
                <?php
				if($total == 0){
					echo '<tr><td colspan="4" align="center">Ups, Keranjang kosong!</td></tr></table>';
					echo '<p><div align="right">
						
						</div></p>';
				} else {
					echo '
						<tr style="background-color: #DDD;"><td colspan="4"><b>Total :</b></td><td><b><center>Rp. '.number_format($total,2,",",".").'</center></b></td></td></td><td></td><td></td></tr></table>
						
					';
				}
				?>
                </div>
				</form>
                <div class="hero-unit"><h3>Total Belanja Anda Rp. <?php echo number_format($total,2,",","."); ?>,-</h3>Untuk informasi pembayaran silahkan hubungi 08xxxxxxxx
                    <?php 
                    $sql = mysqli_query($con," SELECT * FROM bukti where id_user = '$_SESSION[id]' and kode_penjualan = '$_GET[kode_penjualan]'");
                    $query = mysqli_fetch_array($sql);
                    if (!$query) { ?>
                    <p><div align="right">
                        
                        <a href="#popup" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart icon-white"></i>UPLOAD BUKTI PEMBAYARAN &raquo;</a>
                        </div></p>
                    
                <form method="post" enctype="multipart/form-data">
<div id="popup" class="overlay" >
    <div class="popup">
        <a class="close" href="#">&times;</a>
        <div class="content">
            <div class="hero-unit">
               <?php 
            $sql = "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '$_GET[kode_penjualan]'";
            $query = mysqli_query($con , $sql);
            $data = mysqli_fetch_array($query);
             ?>
             <h3>No : <?php echo $data['kode_penjualan'] ?></h3> 

        <table class="table table-condensed">
            <tr>
                <td >Masukkan Struk Pembelian</td>
                <td><input type="file" name="gambar"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" class="btn btn-success" name="upload" value="upload"></td>
                
            </tr>
        </table>
            </div>
        </div>
    </div>
</div>
                </form>
                    <?php }  else { ?>
                    <?php
                    $sql = "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '$_GET[kode_penjualan]'";
            $query = mysqli_query($con , $sql);
            $data = mysqli_fetch_array($query);?>
                    <div>
                        Status pengiriman barang anda : <?php echo $data['status']; ?> 
                    </div>
                    <?php } ?>
                </div>  
                </div>
			<!-- end: Table -->

		</div>
		<!-- end: Container -->
				
	</div>
	<!-- end: Wrapper  -->			

    <!-- start: Footer Menu -->
	<div id="footer-menu" class="hidden-tablet hidden-phone">

		<!-- start: Container -->
		<div class="container">
			
			<!-- start: Row -->
			<div class="row">

				<!-- start: Footer Menu Logo -->
				
				<div class="span1">
						
					<div id="footer-menu-back-to-top">
						<a href="#"></a>
					</div>
				
				</div>
				<!-- end: Footer Menu Back To Top -->
			
			</div>
			<!-- end: Row -->
			
		</div>
		<!-- end: Container  -->	

	</div>	
	<!-- end: Footer Menu -->

	<div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
	<div id="copyright">
		<div class="container">
		
			<p>
				Copyright &copy; <a href="#">EithreeShop 2018</a> <a href="http://bootstrapmaster.com" alt="Bootstrap Themes">Bootstrap Themes</a> designed by BootstrapMaster
			</p>
	
		</div>
	</div>	
	<!-- end: Copyright -->

<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script def src="../js/custom.js"></script>

<script src="jquery.validate.js"></script>
    <script>
    $(document).ready(function(){
        $("#formku").validate();
    });
    </script> 
    
    <style type="text/css">
    label.error {
        color: red;
        padding-left: .5em;
    }
    </style>
<!-- end: Java Script -->

</body>
</html>