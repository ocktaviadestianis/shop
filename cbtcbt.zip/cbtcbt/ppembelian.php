<a href="" onclick="window.print()">PRINT</a></p>
<?php 
include('pembelian.php');
$a = date('d-m-Y');
$b = date('H:i:s');
echo "Tanggal : $a </br> ";
echo "Jam : $b";
?>
<p><a href="exportt.php"><button>Export Data Ke Excel</button>
<br>
<br>
<a href="pdff.php"><button>Export Data ke Pdf</button></a>
</br></a>