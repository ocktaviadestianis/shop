<?php 
date_default_timezone_set("Asia/Jakarta");
include '../config/koneksi.php';
include '../library/oop.php';
 session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='login.php'</script>";
 }
 

if (isset($_GET['logout'])) {
        session_destroy();
        ?>
        <script>window.location.href="index.php"</script>
        <?php
    }
if (isset($_POST['simpan'])){
		$tanggal = date('Y-m-d H:i:s');
		$sql = "INSERT INTO komen VALUES ('$_POST[nama]', '$_POST[email]', '$_POST[komentar]', '$tanggal')";
		$query = mysqli_query($con, $sql);
		if($query){
			echo "<script>alert('Komentar anda kami terima..');document.location.href='?menu=daftar'</script>";
		}
	}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
    <style type="text/css">
    .konten
{
    margin-top: 20px;
    margin-left: 350px;
    margin-right: 15px;
	color: black;
	font-family: calibri;
    font-size: 20px;
    font-weight: none;	
}
.komentar
{
    position: center;
    margin-top: 20px;
    margin-left: 340px;
    margin-right: 15px;
	color: gray;
	font-family: calibri;
    font-size: 14px;
    font-weight: none;	
    border: 1px solid #;
    width: 700px;
    height: 260px;
    overflow: scroll;
}
    </style>
</head>
<body>
    
	<header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../user/halaman.php">Beranda</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>

                                    <li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Struk<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '0'"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('apa anda yakin?')" name="logout">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
    
	<div id="wrapper">

    	<div class="container"> 
        <center><div class="title" style="margin-left: ;"><h3>Berikan Komentar</h3></div></center>
            <form id="formku" method="post" action="" >
<table style="font-style: arial; font-weight: bold; margin-left: 140px;">
<tr>
<td width="150">Nama</td>
<td width="30">:</td>
<td width="550"><input type="text" name="nama" size="30" class="required" minlength="3" placeholder="Nama Anda" /></td>
</tr>
<tr>
<td width="150">Email</td>
<td width="30">:</td>
<td width="550"><input type="text" name="email" size="30" class="required email" minlength="3" placeholder="Alamat Email" /></td>
</tr>
<tr>
<td width="150">Komentar</td>
<td width="30">:</td>
<td width="550"><input type="text" name="komentar" size="30" class="required" minlength="3" placeholder="Komentar Anda " /></td>
</tr>
<tr>
<td width="150"></td>
<td width="30"></td>
<td width="550">
<input class="btn btn-sm btn-primary" type="submit" name="simpan" value="Kirim"/>
</td>
</tr>
</table>
</form>
</div>
<div class="komentar">
	<?php 
$sql = mysqli_query($con, "SELECT * FROM komen");
$tampil = mysqli_fetch_array($sql);
$no = 0;
foreach ($sql as $tampil) {
	$no++;
		 echo "<tr><td>$tampil[tanggal]&nbsp;&nbsp;</td></tr>";
         echo "<tr><td><h4 >$tampil[nama]</h4>&nbsp; &nbsp;</td></tr>";
         echo "<tr><td>$tampil[komentar]</td></tr>
         <tr><td>&nbsp;</td><td>&nbsp;</td></tr> <br><br>";
		 
		  } ?>
</div>
</div>
</div>
		</div>
			<br>
			<br>
			<br>
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="../js/custom.js"></script>
</body>
</html>