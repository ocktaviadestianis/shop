<?php 
 
include 'config/koneksi.php';
include 'library/oop.php';
 session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='login.php'</script>";
 }
if (isset($_GET['logout'])) {
        session_destroy();
        ?>
        <script>window.location.href="index.php"</script>
        <?php
    }

 ?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
				</div>
				<div class="span9">
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			          		</a>
			          		<div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class=""><a href="halaman.php">Home</a></li>
                                    <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            
          <?php $sql = mysqli_query($con , "SELECT * FROM Kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                 
                                            
                                        </ul></li>
									<li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
			              			<li><a href="logout.php">Logout</a></li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
				</div>	
			</div>
		</div>
	</header>
	<!-- start: Page Title -->
	<div id="page-title">

		<div id="page-title-inner">

			<!-- start: Container -->
			<div class="container">

				<h2><i class="ico-usd ico-white"></i>Checkout Keranjang</h2>

			</div>
			<!-- end: Container  -->

		</div>	

	</div>
	<!-- end: Page Title -->
	
	<!--start: Wrapper-->
	<div id="wrapper">
				
		<!-- start: Container -->
		<div class="container">

			<!-- start: Table -->
                 <div class="table-responsive">
                 <div class="title"><h3>Checkout Selesai</h3></div>
                 <div class="hero-unit">Selamat Anda telah berhasil checkout, silahkan catat info di bawah ini..</div>
                 <div class="hero-unit">
    <?php 
			if($_POST['finish']){
				session_destroy();
				echo 'Terima kasih Anda sudah berbelanja di Toko Online kami dan berikut ini adalah data yang perlu Anda catat.';
				echo '<p>Total biaya untuk pembelian Produk adalah Rp. '.$_POST['total'].',- dan biaya bisa di kirimkan melalui Rekening Bank Mandiri dengan nomor rekening 123-234-56347-8 atas nama Randy.</p>';
				echo '<p>Bukti Pembayaran di kirim via whatsapp dengan no Telepon</p>';
				echo '<p>Dan barang akan kami kirim ke alamat di bawah ini: 081192999299.</p>';
				echo '<p>Nama Lengkap : '.$_POST['nm_usr'].'<br>';
                echo 'Email : '.$_POST['email_usr'].'<br>';
                echo 'Alamat : '.$_POST['almt_usr'].'<br>';
                echo 'Kode Pos : '.$_POST['kp_usr'].'<br>';
                echo 'Kota : '.$_POST['kota_usr'].'<br>';
                echo 'No Telepon : '.$_POST['tlp'].'<br>';
                echo 'Total Belanja : Rp. '.$_POST['total'].',-</p>';
			}else{
				header("Location: index.php");
			}
			?>
                   </div>
				
			<!-- end: Table -->

		</div>
		<!-- end: Container -->
				
	</div>
	<!-- end: Wrapper  -->			

    <!-- start: Footer Menu -->
	<div id="footer-menu" class="hidden-tablet hidden-phone">

		<!-- start: Container -->
		<div class="container">
			
			<!-- start: Row -->
			<div class="row">

				<!-- start: Footer Menu Logo -->
				<div class="span2">
					<div id="footer-menu-logo">
						<a href="#"><img src="img/logo-footer-menu.png" alt="logo" /></a>
					</div>
				</div>
				<!-- end: Footer Menu Logo -->

				<!-- start: Footer Menu Links-->
				<div class="span9">
					
					<div id="footer-menu-links">

						<ul id="footer-nav">

							<li><a href="#">Kemeja</a></li>

							<li><a href="#">Kaos</a></li>

							<li><a href="#">Sweater</a></li>

							<li><a href="#">Jacket</a></li>
							
							<li><a href="#">Pants & Jeans</a></li>

						</ul>

					</div>
					
				</div>
				<!-- end: Footer Menu Links-->

				<!-- start: Footer Menu Back To Top -->
				<div class="span1">
						
					<div id="footer-menu-back-to-top">
						<a href="#"></a>
					</div>
				
				</div>
				<!-- end: Footer Menu Back To Top -->
			
			</div>
			<!-- end: Row -->
			
		</div>
		<!-- end: Container  -->	

	</div>	
	<!-- end: Footer Menu -->
<div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
</body>
</html>