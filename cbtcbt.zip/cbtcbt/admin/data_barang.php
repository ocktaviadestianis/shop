<?php require_once("../config/koneksi.php");
date_default_timezone_set("Asia/jakarta");
include "../config/koneksi.php";
include "../library/oop.php";

  $a = date('d-m-Y');
  $b = date('H:i:s');

$perintah = new oop();

@$table = "barang";

?>


<h1 align="center">Laporan Barang</h1>
<table border="1" align="center" cellpadding="10" cellspacing="0">
	<tr>
						<th>No</th>
						<th>Kategori</th>
						<th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Harga Barang</th>
                        <th>Stok</th>
					</tr>
					</thead>
					<?php 
			 	$tampil = $perintah->tampil($con, $table);
			 	$no = 0;
			 	foreach($tampil as $field) {
			 		$no++
			 	 ?>
					
						<tr>
							<td><?php echo $no; ?></td>
							<td><?php echo $field['kategori']; ?></td>
							<td><?php echo $field['kd_barang']; ?></td>
                            <td><?php echo $field['nama_barang']; ?></td>
                            <td><?php echo $field['harga_barang']; ?></td>
                            <td><?php echo $field['stok']; ?></td>
			 	 		</tr>
	 <?php } ?>
</table>
 <?php 

	

	$a = date('d-m-Y');
	$b = date('H:i:s');

	echo "Tanggal : $a </br>";
	echo "Jam : $b";

 ?>	
<script>
	window.print();
</script>