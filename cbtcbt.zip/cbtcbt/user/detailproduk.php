<?php 
include '../config/koneksi.php';
include '../library/oop.php'; 

session_start();
  
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../user/login.php'</script>";
     if(empty($_SESSION['username'])){
            echo "<script>alert('harap login terlebih dahulu!!! ?');window.location.href='index.php'</script>";
        }
 }
if (isset($_GET['logout'])) {
        session_destroy();
        ?>
        <script>window.location.href="index.php"</script>
        <?php
    }
 $query = mysqli_query($con, "SELECT * FROM barang WHERE kd_barang='$_GET[kd_barang]'");
    $datas  = mysqli_fetch_array($query);
    $jum_stok = $datas['stok'];
    $harga = $datas['harga_barang'];
     $perintah = new oop();
    $table = "tbl_penjualan";
    $redirect = "detail1.php"; 
    if (isset($_POST['beli'])) {
        if ($_POST['jumlah_beli'] > $jum_stok) {
            echo "<script>alert('Jumlah yang anda beli melebihi stok kami');document.location.href='detailproduk.php?kd_barang=".$_GET['kd_barang']."'</script>";
        }else{
        $query = mysqli_query($con, "SELECT * FROM barang WHERE kd_barang='$_GET[kd_barang]'");
        $data  = mysqli_fetch_array($query);
        $sql = mysqli_query($con, "SELECT * FROM tbl_penjualan WHERE kd_barang='$_GET[kd_barang]' AND id_user='$_SESSION[id]' AND kode_penjualan='0'");
        $dati  = mysqli_fetch_array($sql);
        $where = "id = '$dati[id]'";
           if ($data['kd_barang']==$dati['kd_barang']) {
            $jumlah = $_POST['jumlah_beli']+$dati['jumlah'];
            $field = "jumlah ='$jumlah'";
            $perintah->ubah($con, $table,$field, $where, $redirect);
           }else{
            
            $total = $data['harga_barang'] * $_POST['jumlah_beli'];
            $field = "kode_penjualan='0',kd_barang='$data[kd_barang]',nama_barang='$data[nama_barang]',id_user='$_SESSION[id]', jumlah='$_POST[jumlah_beli]', harga_barang='$data[harga_barang]',status='Belum dikirim'";
            $perintah->simpan($con, $table, $field,$redirect);
        }
        }
    }
    

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Eithree Shop</title> 
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
    <header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../user/halaman.php">Beranda</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>

                                    <li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Struk<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '0'"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('apa anda yakin?')" name="logout">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
    
        <div class="container" method="post">             
<form method="post">
    
            <div class="title"><h3>Detail Barang</h3></div>
            <div class="row">
            <div class="col-sm-6">
                    <?php                  

                 $query = mysqli_query($con, "SELECT * FROM barang WHERE kd_barang='$_GET[kd_barang]'");
                 $data  = mysqli_fetch_array($query);
?>
                    <div class="hero-unit" style="margin-left: 20px;">
                    <table>
                    <tr>
                        <td rowspan="7"><img style="width: 150px;height: 150px;" src="../gambar/<?php echo $data['gambar']; ?>"></td>
                        </tr>
                        <tr>
                        <td colspan="4"><div class="title"><h3><?php echo $data['nama_barang']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td size="200"><h3>Harga</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3>Rp.<?php echo $data['harga_barang'];?></h3></div></td>
                        </tr>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Detail</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3><?php echo $data['detail_barang']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Stock</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3>
                            <?php 
                            if ($data['stok']<=0) {
                                echo "barang habis";
                            }else{
                                echo $data['stok'];
                             ?>
                            

                        </h3></div></td>
                         <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                            <div class="clear">
                                <?php if (@$jum_stok == 0) {
                                    
                                }else{ ?>   
                                <input placeholder="Jumlah Beli" required type="number" name="jumlah_beli">
                                <input type="submit"  name="beli" value="BELI" class="btn btn-lg btn-danger">
                                <?php } ?>
                                
                            </div>
                        </td>
                        </tr>
                       <?php } ?>
                    </table>
                    </div>
</form>
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="../js/custom.js"></script>
</body>
</html>