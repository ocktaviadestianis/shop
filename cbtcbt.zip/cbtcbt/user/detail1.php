<?php 
include '../config/koneksi.php';
include '../library/oop.php'; 
$perintah = new oop();
$kode ="";
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../user/login.php'</script>";
 }
if (isset($_GET['logout'])) {
        session_destroy();
        ?>
        <script>window.location.href="index.php"</script>
        <?php
    }

if (@$_GET['act']=="add") {
    $kode = $_GET['kd_barang'];
    $cek =mysqli_query($con,"select * from barang where kd_barang = '$kode'");
    $data = mysqli_fetch_array($cek);
    $sql2="select * from tbl_penjualan where kd_barang='$kode' and id_user='$_SESSION[id]'";
    $query2 = mysqli_query($con,$sql2);
    $data2= mysqli_fetch_array($query2);
    $cek2 = mysqli_num_rows($query2);
    if ($cek2>0) {
        $stok_new = $data['stok']-1;
        $stok =mysqli_query($con,"update barang set stok ='$stok_new' where kd_barang = '$kode'");
        $eksekusi = mysqli_query($con,$stok);
        $jumlah_new= $data2['jumlah']+1;
        $update_sql = "update tbl_penjualan set jumlah = '$jumlah_new' where kd_barang='$kode' and id_user='$_SESSION[id]'";
        $q = mysqli_query($con,$update_sql);
        if ($q) {
        ?>
         <script type="text/javascript">alert("success");window.location.href="<?php echo '../user/detail1.php?kd_barang='.$kode?>"</script>
        <?php
    }else{
        echo mysqli_error($con);
    }
    }else{

    $query = mysqli_query($con,"INSERT INTO `tmp_barang` (`nama_barang`, `satuan`, `harga_barang`, `sub_total`, `id_user`, `kd_barang`) VALUES ('$data[nama_barang]', '1', '$data[harga_barang]', '', '$_SESSION[id]', '$_GET[kd_barang]');");
    if ($query) {
        ?>
         <script type="text/javascript">alert("success");window.location.href="<?php echo '../user/detail1.php?kd_barang='.$kode?>"</script>
        <?php
    }else{
        echo mysqli_error($con);
    }
    }
}
if (@$_GET['act']=="kurang") {
    $kd_barang = $_GET['kd_barang'];
    $sql = "select * from tbl_penjualan where kd_barang = '$kd_barang' and id_user='$_SESSION[id]'";
    $query = mysqli_query($con,$sql);
    $data = mysqli_fetch_array($query);
    if ($data['jumlah']<2) {
        $sql1 = "delete from tbl_penjualan where kd_barang = '$kd_barang' and id_user='$_SESSION[id]'";
        $query1 = mysqli_query($con,$sql1);
        if ($query1) {
        ?>
        <script>alert("success");window.location.href="../user/detail1.php"</script>
        <?php
        }else{
            echo mysqli_error($con);
        }
    }else{
        $satuan_new = $data['jumlah']-1;
        $sql2 = "update tbl_penjualan set jumlah='$satuan_new' where kd_barang = '$kd_barang' and id_user='$_SESSION[id]'";
        $query2 = mysqli_query($con,$sql2);
        if ($query2) {
        ?>
        <script>alert("success");window.location.href="../user/detail1.php"</script>
        <?php
        }else{
            echo mysqli_error($con);
        }
    }
}
if (@$_GET['act']=="hapus") {

    $kd_barang = $_GET['kd_barang'];
    $sql = "delete from tbl_penjualan where kd_barang = '$kd_barang' and id_user='$_SESSION[id]'";
    $query = mysqli_query($con,$sql);   
        if ($query) {
        ?>
        <script>alert("success");window.location.href="../user/detail1.php"</script>
        <?php
        }else{
            echo mysqli_error($con);
        }     
}
if (isset($_GET['checkout'])) {
    $unique = uniqid();
    // $sql = "UPDATE tbl_penjualan SET kode_penjualan = '$unique' WHERE id_user = '$id'";
    $sql = "UPDATE tbl_penjualan SET kode_penjualan = '$unique' WHERE kode_penjualan = '0' AND id_user='$_SESSION[id]'";
    $query = mysqli_query($con,$sql);
    if ($query) {
        echo "<script>alert('masukan bukti pembayaran');window.location.href='bukti.php?kode_penjualan=$unique'</script>";
    }else{
        echo "<script>alert('error');window.location.href='struk.php';</script>";
    }
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
	<header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../user/halaman.php">Beranda</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>

                                    <li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Struk<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
          <?php $sql = mysqli_query($con , "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' GROUP BY `kode_penjualan`"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="bukti.php?kode_penjualan=<?php echo $field['kode_penjualan'] ?>"><?php echo $field['kode_penjualan']; ?></a></li>
          <?php } ?>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('apa anda yakin?')" name="logout">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
    
    <?php 
    $sql = mysqli_query($con , "SELECT * FROM tbl_penjualan where id_user = '$_SESSION[id]' and kode_penjualan = '0'");
    $query = mysqli_fetch_array($sql);
    if ($query ) {
    ?>
    <form method="post">
        
        <div class="container" method="post">             

            <div class="title"><h3>Detail Keranjang Belanja</h3></div>
            <div class="row">
            <div class="col-sm-6">
            <div class="hero-unit">
                <table class="table table-hover table-condensed" border="">
                    <tr>
                    <th><center>No</center></th>
                    <th><center>Kode Barang</center></th>
                    <th><center>Nama Barang</center></th>
                    <th><center>Jumlah Satuan</center></th>
                    <th><center>Harga Satuan</center></th>
                    <th><center>Sub Total</center></th>
                    <th><center>Status</center></th>
                    <th><center>Opsi</center></th>
                    
                    </tr>
                    <?php 

                    if (@$_GET['act']=="hapus") {
                      $sql = "delete from tbl_penjualan where kd_barang='$_GET[kd_barang]' and id_user='$_SESSION[id]' and kode_penjualan = '0'";
                      $query = mysqli_query($con,$sql);
                      if ($query) {
                      ?>
                    <script>alert("success");window.location.href="../user/detail1.php"</script>
                      <?php
                      }else{
                        echo mysqli_error($con);
                      }
                      }
                    $sql = "SELECT * FROM tbl_penjualan where id_user='$_SESSION[id]' and kode_penjualan = '0'";
                    $query = mysqli_query($con ,  $sql);
                    $no=0;
                    $total = 0;
                    while ($data = mysqli_fetch_array($query)) {
                        $no++;
                        $jumlah = $data['harga_barang'] * $data['jumlah'];
                        $total += $jumlah
                     ?>
                    <tr>
                        <td><center><?php echo $no; ?></center></td>
                        <td><center><?php echo $data['kd_barang'] ?></center></td>
                        <td><center><?php echo $data['nama_barang'] ?></center></td>
                        <td><center><?php echo $data['jumlah'] ?></center></td>
                        <td><center><?php echo $data['harga_barang'] ?></center></td>
                        <td><center><?php echo $jumlah; ?></center></td>
                        <td><center><?php echo $data['status']; ?></center></td>
                        <td>
                        <center>
                            <a href="../user/detail1.php?id_user=<?php echo $_SESSION['id']?>&act=hapus&kd_barang=<?php echo $data['kd_barang'] ?>" class="btn btn-xs btn-danger" name="hapus" onclick="return confirm('Hapus?')">Delete</a>
                            <a href="../user/detail1.php?id_user=<?php echo $_SESSION['id']?>&act=kurang&kd_barang=<?php echo $data['kd_barang'] ?>" class="btn btn-xs btn-warning" name="hapus" onclick="return confirm('Mengurangi satu jumlah barang?')">Kurang</a>
                            <a href="../user/detail1.php?id_user=<?php echo $_SESSION['id']?>&act=add&kd_barang=<?php echo $data['kd_barang'] ?>" class="btn btn-xs btn-success" name="hapus" onclick="return confirm('Menambah satu jumlah barang?')">Tambah</a>
                        </center>
                        </td>
                    </tr>
                    <?php }
                    ?>
                    <tr>
                        <td colspan="7" ><h3>Total Belanja Anda :</h3></td>
                        <td>Rp. <?php echo number_format($total); ?>,-</td>
                    </tr>
                </table>
                <div align="right">
                    <a href="halaman.php" class="btn btn-success" >Belanja Lagi</a>
                        <a href="../user/detail1.php?checkout&id_user=<?= $_SESSION['id'] ?>" class="btn btn-success" >Checkout </a>
                        </div></p>

            </div>
                
    </form>
    <?php } else{?>
    <div class="container" method="post">             

            <div class="title"><h3>Detail Keranjang Belanja</h3></div>
            <div class="row">
            <div class="col-sm-6">
            <div class="hero-unit">
        
      <h3>Keranjang Kosong!</h3>
      <a href="halaman.php" class="btn btn-success" >Mulai Belanja </a>
  </div>
</div>
</div>
</div>
    <?php }?>
            </div>
                </div>  
                
                    
                </div>
                
                </div>
            </div>
            
        </div>
                
    </div>
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="../js/custom.js"></script>
</body>
</html>