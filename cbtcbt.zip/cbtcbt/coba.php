<?php 
include 'config/koneksi.php';
include 'library/oop.php'; 
$perintah = new oop();
$kode ="";
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='login.php'</script>";
 }
if (@$_GET['act']=="add") {
    $kode = $_GET['kd_barang'];
    $cek =mysqli_query($con,"select * from barang where kd_barang = '$kode'");
    $data = mysqli_fetch_array($cek);
    $query = mysqli_query($con,"INSERT INTO `tmp_barang` (`nama_barang`, `satuan`, `harga_barang`, `sub_total`, `id_user`, `kd_barang`) VALUES ('$data[nama_barang]', '$data[satuan]', '$data[harga_barang]', '', '$_SESSION[id]', '$_GET[kd_barang]');");
    if ($query) {
        ?>
         <script type="text/javascript">alert("success");window.location.href="<?php echo 'detailproduk.php?kd_barang='.$kode?>"</script>
        <?php
    }else{
        echo mysqli_error($con);
    }
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
				</div>
				<div class="span9">
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			          		</a>
			          		<div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class=""><a href="halaman.php">Home</a></li>
                                    <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            
          <?php $sql = mysqli_query($con , "SELECT * FROM Kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                 
                                            
                                        </ul></li>
									<li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detailproduk.php">Keranjang</a></li>
			              			<li><a href="logout.php">Logout</a></li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
				</div>	
			</div>
		</div>
	</header>
        <div class="container" method="post">             

            <div class="title"><h3>Detail Barang</h3></div>
            <div class="row">
            <div class="col-sm-6">
                    <?php                  

                 $query = mysqli_query($con, "SELECT * FROM barang WHERE kd_barang='$_GET[kd_barang]'");
                 $data  = mysqli_fetch_array($query);
?>
                    <div class="hero-unit" style="margin-left: 20px;">
                    <table method="post">
                    <tr>
                        <td rowspan="7"><img style="width: 150px;height: 150px;" src="gambar/<?php echo $data['gambar']; ?>"></td>
                        </tr>
                        <tr>
                        <td colspan="4"><div class="title"><h3><?php echo $data['nama_barang']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td size="200"><h3>Harga</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3>Rp.<?php echo number_format($data['harga_barang'],2,",",".");?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Stock</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><input type="number" name="satuan"><?php echo @$data['satuan'] ?></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Detail</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3><?php echo $data['detail_barang']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><div class="clear" name="beli"> <a  href="detailproduk.php?act=add&kd_barang=<?php echo $data['kd_barang']; ?>&id_user=<?php echo $_SESSION['id'] ?>" class="btn btn-lg btn-danger" name="beli" >Beli &raquo;</a></div></td>
                       
                        </tr>
                    </table>
                    </div>

                    <div class="title">
                    <h3>Keranjang Anda</h3></div>
            <div class="hero-unit">
                <table class="table table-hover table-condensed" border="1">
                    <tr>
                    <th><center>No</center></th>
                    <th><center>Nama Barang</center></th>
                    <th><center>Satuan</center></th>
                    <th><center>Harga Satuan</center></th>
                    <th>sub total</th>
                    
                    </tr>
                    <?php 
                    $sql = "SELECT * FROM tmp_barang where id_user='$_SESSION[id]'";
                    $query = mysqli_query($con ,  $sql);
                    $no=0;
                    $total = 0;
                    while ($data = mysqli_fetch_array($query)) {
                        $no++;
                        $jumlah = $data['harga_barang'] * $data['satuan'];
                        $total += $jumlah
                     ?>
                    <tr>
                        <td><?php echo $no; ?></td>
                        <td><?php echo $data['nama_barang'] ?></td>
                        <td><?php echo $data['satuan'] ?></td>
                        <td><?php echo $data['harga_barang'] ?></td>
                        <td><?php echo $jumlah; ?></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="4" ><h3>Total Belanja Anda :</h3></td>
                        <td>Rp. <?php echo number_format($total); ?>,-</td>
                    </tr>
                </table>
                <div align="right">
                        <a href="detail1.php?id_user=<?php echo $_SESSION['id'] ?>" class="btn btn-success">Detail Keranjang </a>
                        </div></p>
            </div>
                
            </div>
                </div>  
                
                    
                </div>
                
                </div>
            </div>
            
        </div>
                
    </div>
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
</body>
</html>