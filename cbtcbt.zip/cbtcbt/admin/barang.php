<?php 
include '../config/koneksi.php';
include '../library/oop.php';
error_reporting(0);
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../admin'</script>";
}

$perintah = new oop();
@$nama_file = $_FILES['gambar']['name'];
@$tmp_file = $_FILES['gambar']['tmp_name'];
@$field ="kategori = '$_POST[kategori]', kd_barang = '$_POST[kd_barang]', nama_barang = '$_POST[nama_barang]', harga_barang = '$_POST[harga_barang]', detail_barang = '$_POST[detail_barang]', stok = '$_POST[stok]', gambar = '$nama_file'  " ;

$table= 'barang';
$redirect="barang.php";
@$where = "kd_barang = '$_GET[id]'";

if (isset($_POST['simpan'])) {
  move_uploaded_file($tmp_file, "../gambar/".$nama_file);
    $perintah->simpan($con , $table , $field , $redirect);
}
if (isset($_GET['hapus'])) {
  $perintah->hapus($con , $table , $where , $redirect);
}
if (isset($_GET['edit'])) {
  $edit = $perintah->edit($con , $table, $field ,$where);
}
if (isset($_POST['ubah'])) {
  move_uploaded_file($tmp_file, "../gambar/".$nama_file);
  $data = "kategori = '$_POST[kategori]', nama_barang = '$_POST[nama_barang]', harga_barang = '$_POST[harga_barang]', detail_barang = '$_POST[detail_barang]', stok = '$_POST[stok]', gambar = '$nama_file'  " ;
  $perintah->ubah($con , $table , $data , $where , $redirect);
}                                                                       
?>


<!DOCTYPE html>
  <meta property="og:image" content=""/>
  <link href="../css/bootstrap.css" rel="stylesheet">
  <link href="../css/bootstrap-responsive.css" rel="stylesheet">
  <link href="../css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title> 
	
<body>
<header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../admin/admin.php">Home</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/kategori.php">Input Kategori</a></li>
                                            <li><a href="../admin/barang.php">Input Barang</a></li>
                                           
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Laporan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/laporan_kategori.php">Laporan Kategori</a></li>
                                            <li><a href="../admin/laporan_barang.php">Laporan Barang</a></li>
                                            
                                            
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pelanggan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                          <li><a href="../admin/resi.php">Resi Pelanggan</a></li>
                                            <li><a href="../admin/testimoni.php">Testimoni Pelanggan</a></li>
                                            <li><a href="../admin/daftar_beli.php">Barang Pelanggan</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('Yakin mau keluar?')">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
   <div id="wrapper">
    <div class="container">
     <div class="table-responsive">
       <div class="title"><h3>Input Barang</h3></div>

       <form id="formku" action="" enctype="multipart/form-data" method="post">
        <table class="table table-condensed">
          <input type="hidden" name="total" value="">

          <tr>
            <td><label for="kd_kategori">Kode Kategori</label></td>
            <td>
              <select name="kategori" class="required" type="text">
                <?php $sql = mysqli_query($con , "SELECT * FROM kategori"); 
                // $row = mysqli_fetch_assoc($sql);
                foreach ($sql as $field ) {
                  ?>
                  <option value="<?php echo $field['kategori'] ?>" ><?php echo $field['kategori']; ?></option>
                  <?php } ?>
                </select>
              </td>
            </tr>
            <tr>
              <td><label >Kode Barang</label></td>
              <td><input name="kd_barang" type="text" readonly value="<?php if($_GET['id']==null){echo @$perintah->autokode($con , $table , "kd_barang" ,"B");}else{echo $_GET['id'];} ?>" ></td>
            </tr>
            <tr>
              <td><label >Nama Barang</label></td>
              <td><input name="nama_barang" type="text" class="required" value="<?php echo @$edit[nama_barang] ?>"/></td>
            </tr>
            <tr>
              <td><label >Harga Barang</label></td>
              <td><input name="harga_barang" type="number" class="required" value="<?php echo @$edit[harga_barang] ?>" /></td>
            </tr>
            <tr>
              <td><label >Detail Barang</label></td>
              <td><textarea name="detail_barang" type="text" class="required"><?php echo @$edit[detail_barang]?></textarea>
              </td>
            </tr>
            <tr>
              <td><label >Stok</label></td>
              <td><input name="stok" type="number" class="required" value="<?php echo @$edit[stok] ?>" /></td>
            </tr>
            <tr>
              <td><label >Gambar</label></td>
              <td><?php if (@$_GET[id] == ""){?>  
                <input type="file" name="gambar" required>
              <?php }else{ ?>
                <h4>Masukan gambar lagi ?</h4>
                <a class="btn btn-success" href="?menu=redirect&edit&id=<?=$_GET['id']?>&jawab=Y">YA</a>
               
                <?php if($_GET['jawab']=="Y"){ ?>
                  <input type="file" name="gambar" value="<?php echo @$edit[gambar] ?>">
                <?php }?>
               <?php } ?></td>
            </tr>
            <td></td>
            <td><?php if(@$_GET['id'] == ""){ ?>
              <input type="submit" name="simpan" value="SIMPAN" class="btn btn-sm btn-primary">
              <?php }else{ ?>
              <input type="submit" name="ubah" value="UBAH" class="btn btn-sm btn-primary">
              <?php } ?>
              &nbsp;&nbsp;
              <a href="../admin/admin.php" class="btn btn-sm btn-primary">Kembali</a></td>
            </tr>
          </table>
        </form>
      </div>
      <div id="wrapper">

        <!-- start: Container -->
        <div class="container">

         <!-- start: Table -->
         <div class="table-responsive">
           <div class="title"><h3>Data Barang</h3></div>
           <div class="container">
            <div class="row"><br>
              <table class="table table-striped">
                <th>NO</th>
                <th>Kategori</th>
                <th>Kode Bar`ang</th>
                <th>Nama Barang</th>
                <th>Harga Barang</th>
                <th>Detail Barang</th>
                <th>Stok</th>
                <th>Gambar</th>
                <th colspan="2">Aksi</th>
                <?php 
                $tampil = $perintah->tampil($con , $table);
                $no = 0;
                foreach ($tampil as $field) {
                  $no++

                  ?>
                  <tr>
                   <td><?php echo $no; ?></td>
                   <td><?php echo $field['kategori']; ?></td>
                   <td><?php echo $field['kd_barang']; ?></td>
                   <td><?php echo $field['nama_barang']; ?></td>
                   <td><?php echo $field['harga_barang']; ?></td>
                   <td><?php echo $field['detail_barang']; ?></td>
                   <td><?php echo $field['stok']; ?></td>
                   <td><img style="width: 50px;height: 50px;" src="../gambar/<?php echo $field['gambar']; ?>"></td>
                   <td colspan="2"><a onclick="return confirm('Yakin akan di hapus?')" href="?menu=redirect&hapus&id=<?php echo @$field[kd_barang] ?>">HAPUS</a> &nbsp;&nbsp;
                    <a href="?menu=redirect&edit&id=<?php echo @$field[kd_barang] ?>">EDIT</a></td>
                  </tr>
                  <?php 
                }
                ?>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  

    <!-- start: Java Script -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/jquery-1.8.2.js"></script>
    <script src="../js/bootstrap.js"></script>
    <script src="../js/flexslider.js"></script>
    <script src="../js/carousel.js"></script>
    <script src="../js/jquery.cslider.js"></script>
    <script src="../js/slider.js"></script>
    <script def src="../js/custom.js"></script>

    <script src="jquery.validate.js"></script>
  </body>
  </html>