<?php require_once("../config/koneksi.php");
date_default_timezone_set("Asia/jakarta");
include "../config/koneksi.php";
include "../library/oop.php";

  $a = date('d-m-Y');
  $b = date('H:i:s');

$perintah = new oop();

@$table = "query_barang";

?>


<h1 align="center">Laporan Kategori</h1>
<table border="1" align="center" cellpadding="10" cellspacing="0">
	<tr>
		<td>No</td>
		<td>kd Kategori</td>
		<td>Nama Kategori</td>
	</tr>
	<?php 
		$sql = mysqli_query($con, "SELECT * FROM kategori ORDER BY kd_kategori ASC");
		$no = 0;
		while ($data = mysqli_fetch_assoc($sql)){
			$no++
	 ?>
	 <tr>
	 	<td><?php echo $no ?></td>
	 	<td><?php echo $data['kd_kategori'] ?></td>
	 	<td><?php echo $data['kategori'] ?></td>
	 </tr>
	 <?php } ?>
</table>
 <?php 

	

	$a = date('d-m-Y');
	$b = date('H:i:s');

	echo "Tanggal : $a </br>";
	echo "Jam : $b";

 ?>	
<script>
	window.print();
</script>