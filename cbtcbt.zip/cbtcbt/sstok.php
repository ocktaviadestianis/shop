<a href="" onclick="window.print()">PRINT</a></p>
<?php 
include('stok.php');
$a = date('d-m-Y');
$b = date('H:i:s');
echo "Tanggal : $a </br> ";
echo "Jam : $b";
?>
<p><a href="export.php"><button>Export Data Ke Excel</button>
<br>
<br>
<a href="pdf.php"><button>Export Data ke Pdf</button></a>
</br></a>