<?php  
include '../config/koneksi.php';
include '../library/oop.php';

@$table = 'admin';
@$username = $_POST['user'];
@$password = $_POST['pass'];
@$form = 'admin.php';
$perintah = new oop();
session_start();
$_SESSION['login'] = false;
if (isset($_POST['login'])) {
  $login = mysqli_query($con,"select * from admin where username='$username' and password = '$password'");
  if (mysqli_num_rows($login)>0) {
  $data  = mysqli_fetch_array($login);
  $_SESSION['username'] = $data['username'];
  $_SESSION['login'] = true;  
  ?>
  <script type="text/javascript">alert("success");window.location.href="../admin/admin.php"</script>
  <?php
  }else{
    echo "<script>alert('gagal');document.location.href='../admin/index.php'</script>";
  }
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LOGIN</title>

    <!-- Bootstrap -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<div class="container">
    <div class="row"><br>
      <br>
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <div class="panel panel-default">
          <div class="panel-body">
            <form method="post" action="">
              <h1><center >L O G I N  A D M I N</center></h1>
              <hr>
              <div class="form-group">
                <label>Username</label>
                <input type="text" name="user" class="form-control" placeholder="Username admin" required>
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="pass" class="form-control" placeholder="Password admin" required>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block" name="login">login</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../assets/js/bootstrap.min.js"></script>
  </body>
</html>