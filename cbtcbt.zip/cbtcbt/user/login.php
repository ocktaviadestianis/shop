<?php  
include '../config/koneksi.php';
include '../library/oop.php';

@$table = 'user';
@$username = $_POST['user'];
@$password = $_POST['pass'];
@$form = 'halaman.php';
$perintah = new oop();
session_start();

if (isset($_POST['login'])) {
  $login = mysqli_query($con,"SELECT * FROM user where username='$username' and password = '$password'");
  if (mysqli_num_rows($login)>0) {
  $data  = mysqli_fetch_array($login);
  $_SESSION['id'] = $data['id_user'];
  $_SESSION['username'] = $data['username'];
  $_SESSION['nama'] = $data['nama'];
  $_SESSION['login'] = true;  
 echo "<script>alert('SELEMAT DATANG $data[nama]');document.location.href='halaman.php'</script>";
  }else{
    echo "<script>alert('gagal');document.location.href='../user/login.php'</script>";
  }
}



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>LOGIN</title>

    <!-- Bootstrap -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body background="../gambar/a.jpg">
	<div class="container">
    <div class="row"><br>
      <br>
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <div class="panel panel-default">
          <div class="panel-body">
            <form method="post" action="" >
              <h1><center >L O G I N </center></h1>
              <hr>
              <div class="form-group">
                <label>Username</label>
                <input type="text" name="user" class="form-control" placeholder="Username" required>
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="pass" class="form-control" placeholder="Password" required>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block" name="login">login</button>
              </div>
              <div class="form-group">
                <a href="daftar.php">Daftar disini!</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>