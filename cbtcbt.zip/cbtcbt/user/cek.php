<?php 
include '../config/koneksi.php';
include '../library/oop.php';


 session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../user/login.php'</script>";
 }
if (isset($_GET['logout'])) {
        session_destroy();
        ?>
        <script>window.location.href="index.php"</script>
        <?php
    }

$tanggal = date('y-m-d H:i:s');
$perintah = new oop();
@$field ="id_user = '$_SESSION[id]', nama_penerima = '$_POST[nama_penerima]', alamat = '$_POST[alamat]', kode_pos = '$_POST[kode_pos]', no_telp = '$_POST[no_telp]', no_rekening = '$_POST[no_rekening]', nama_rekening = '$_POST[nama_rekening]', bank = '$_POST[bank]', total_harga = '$_POST[total_harga]', status = '$_POST[status]','$tanggal' " ;

$table= 'cekout';
$redirect="../user/cek.php";
@$where = "id_user='$_SESSION[id]'";

if (isset($_POST['simpan'])) {
    $perintah->simpan($con , $table , $field , $redirect);
}
if (isset($_GET['hapus'])) {
  $perintah->hapus($con , $table , $where , $redirect);
}
if (isset($_GET['edit'])) {
  $edit = $perintah->edit($con , $table, $field ,$where);
}
if (isset($_POST['ubah'])) {
   $perintah->ubah($con , $table , $data , $where , $redirect);
}                                                                       
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Eithree Shop</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
  <link href="../css/style.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
  <header>
    <div class="container">
      <div class="row">
        <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
        <div class="span9">
          <div class="navbar navbar-inverse">
              <div class="navbar-inner">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      
                    </a>
                    <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class=""><a href="halaman.php">Home</a></li>
                                    <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            
          <?php $sql = mysqli_query($con , "SELECT * FROM Kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="../user/tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                 
                                            
                                        </ul></li>
                  <li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detail1.php">Keranjang</a></li>
                          <li><a href="logout.php">Logout</a></li>
                      </ul>
                    </div>
                </div>
              </div>
        </div>  
      </div>
    </div>
  </header>

  <body>
   <div id="wrapper">
    <div class="container">
     <div class="table-responsive">
       <div class="title"><h3>Checkout</h3></div>
<form method="post">
  
       <form id="formku" action="" enctype="multipart/form-data" method="post">
        <table class="table table-condensed">
          <input type="hidden" name="total" value="">
            <tr>
              <td><label >Nama penerima</label></td>
              <td><input name="nama_penerima" type="text" ></td>
            </tr>
            <tr>
              <td><label >Alamat</label></td>
              <td><textarea name="no_telp" type="number" maxlength="12" class="required"></textarea></td>
            </tr>
            <tr>
              <td><label >Kode Pos</label></td>
              <td><input name="kodepos" type="number" class="required" /></td>
            </tr>
            <tr>
              <td><label >No Telpon</label></td>
              <td><input name="no_telp" type="number" class="required" /></td>
             </tr>
            
            <td></td>
            <td>
              <input type="submit" name="simpan" value="Beli Sekarang" class="btn btn-sm btn-primary" >
              &nbsp;&nbsp;
              <a href="../user/detail1.php" class="btn btn-sm btn-primary">Kembali</a></td>
            </tr>
          </table>
        </form>
</form>
      </div>
<div id="footer">
        <div class="container">
            <div class="row">
                <div class="span3">
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                </div>
                <div class="span3">
                    <h3>Alamat Kami</h3>
                    <p>
                        jalan Cipinang Gading, Bogor Selatan , Jawa Barat
                    </p>
                </div>
                <div class="span6">
                    <h3>Hubungin Kami</h3>
                    <ul class="social">
                        <h4>Instagram : <a href="http://www.instagram.com/eithree_shop/">eithree_shop</a></h4><br>
                        <h4>Email : <a href="mailto:eithree_shop@gmail.com">eithree_shop</a></h4><br>
                        <h4>Line : aiiimeenhlt</h4><br>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="../js/custom.js"></script>
</body>
</html>