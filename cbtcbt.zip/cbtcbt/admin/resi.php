<?php 
include '../config/koneksi.php';
include '../library/oop.php';
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='../admin'</script>";
}
  
    $table = "tbl_bukti";
    $redirect = "resi.php";
    $perintah = new oop();
    
    if (isset($_POST['simpan'])) {
        $sql = mysqli_query($con , "insert into resi values ('$_GET[nama]', '$_GET[kode_penjualan]' , '$_POST[resi]','' )");
        if ($sql) {
            
            $i = mysqli_query($con , "UPDATE tbl_penjualan set status = 'Dikirim' where kode_penjualan = '$_GET[kode_penjualan]'");
        echo "<script>alert('Berhasil');document.location.href='$redirect'</script>";
    }else{
        echo mysqli_error($con);
    }
    }
    if (isset($_GET['hapus'])) {
    $sql= mysqli_query($con , "DELETE FROM resi WHERE kode_penjualan = '$_GET[kode_penjualan]'");
    if ($sql) {
        echo "<script>alert('berhasil');document.location.href='$redirect'</script>";
    }else{
        echo mysqli_error($con);
    }
}
if (isset($_GET['edit'])) {
    $sql= mysqli_query($con, "SELECT * FROM resi WHERE kode_penjualan = '$_GET[kode_penjualan]'");
    $edit = mysqli_fetch_array($sql);
}
if (isset($_POST['update'])) {
    $sql = mysqli_query($con , "UPDATE resi SET nama = '$_GET[nama]' , no_resi = '$_POST[resi]' where kode_penjualan = '$_GET[kode_penjualan]'");
    if ($sql) {
        echo "<script>alert('berhasil');document.location.href='$redirect'</script>";
    }else{
        echo mysqli_error($con);
    }
}
    ?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<title>EithreeShop</title> 

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<link href="../css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
	<header>
        
        <div class="container">
            <div class="row">
              <div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
        </div>
                <div class="span9">
                    
                    <div class="navbar navbar-inverse">
                        <div class="navbar-inner">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class="active"><a href="../admin/admin.php">Home</a></li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/kategori.php">Input Kategori</a></li>
                                            <li><a href="../admin/barang.php">Input Barang</a></li>
                                           
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Laporan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/laporan_kategori.php">Laporan Kategori</a></li>
                                            <li><a href="../admin/laporan_barang.php">Laporan Barang</a></li>
                                            
                                            
                                        </ul>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pelanggan<b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="../admin/bukti.php">Bukti Transfer Pelanggan</a></li>
                                            <li><a href="../admin/testimoni.php">Testimoni Pelanggan</a></li>
                                            <li><a href="../admin/resi.php">Resi Pelanggan</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="logout.php" onclick="return confirm('Yakin mau keluar?')">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </div>
            </div>
        </div>
    </header>
	<div id="wrapper">
		<div class="container">
       <div class="table-responsive">
       <div class="title"><h3>Input Resi</h3></div>
                 <form method="post">
                     
            <form id="form" action="" method="post">
            <table class="table table-condensed">
            <input type="hidden" name="" value="">
            <tr>
              <td><label for="kode">Kode Penjualan</label></td>
              <td><input type="text" name="kode_penjualan" readonly value="<?php echo @$_GET['kode_penjualan'] ?>" ><h5><a href="#popup1">Pilih Penjualan</a></h5></td>
            </tr>
            <tr>
               <td><label for="Masukan no_resi">No Resi</label></td>
               <td><input name="resi" type="text" class="required"  value="<?php echo @$edit[no_resi] ?>" /></td>
              </tr>
              
             <td></td>
               <td><?php if(@$_GET[id] == ""){ ?>
      <input type="submit" name="simpan" value="SIMPAN" class="btn btn-sm btn-primary">
      <?php }else{ ?>
      <input type="submit" name="ubah" value="UBAH" class="btn btn-sm btn-primary">
      <?php } ?>
                &nbsp;&nbsp;
                <a href="../admin/admin.php" class="btn btn-sm btn-primary">Kembali</a></td>
                </tr>
             </table>
            </form>
                 </form>
           </div>
           <div class="table-responsive">
                 <div class="title"><h3>Data Resi</h3></div>
                 <div class="container">
                 <div class="row"><br>
                   <table class="table table-striped">
                     <tr>
                        <th>No</th>
                      <th>Nama</th>
                     <th>Kode Penjualan</th>
                     <th>No Resi</th>
                     <th colspan="2" align="center">Aksi</th>
                     <?php 
                     $tampil = $perintah->tampil($con , "resi");
                     $no = 0;
                     foreach ($tampil as $field) {
                      $no++
                     
                      ?>
                      </tr>
                     <tr>
                       <td><?php echo $no; ?></td>
                       <td><?php echo $field['nama']; ?></td>
                       <td><?php echo $field['kode_penjualan']; ?></td>
                       <td><?php echo $field['no_resi']; ?></td>
                       <td colspan="2"><a onclick="return confirm('Yakin akan di hapus?')" href="?menu=redirect&hapus&kode_penjualan=<?php echo @$field[kode_penjualan] ?>">HAPUS</a> &nbsp;&nbsp;
                     </tr>
                     <?php 
                   }
                      ?>
                   </table>
                 </div>
               </div>
           </div>

           <style type="text/css">
           	.overlay{
     position: fixed;
     top :0;
     bottom: 0;
     left: 0;
     right: 0;
     background-color: rgba(0 , 0, 0, 0.7);        
     transition: opacity 500ms;
     visibility: hidden;
     opacity: 0;
}
.overlay:target{
        visibility: visible;
        opacity: 1;
}
.popup{
        margin: 70px auto;
        padding: 20px;
        background: #fff;
        border-radius: 5px;
        width: 60%;
        position: relative;
        transition: all 5s ease-in-out;
}
.popup .close{
       position: absolute;
       top: 20px;
       right: 30px;
       transition: all 200ms;
       font-size: 30px;
       font-weight: bold;
       text-decoration: none;
       color : grey;       
}
.popup .close:hover{
        color: red;
}
.popup .content{
        max-height: 40%;
        overflow: auto;
}
@media screen and (max-width: 900px;){
        .popup{
                width: 90%;

        }
}
           </style>
<div id="popup1" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
		<div class="content">
		<table class="table table-condensed">
			<tr>
        <td>Nama</td>
        <td>Alamat</td>
				<td>Kode Penjualan</td>
        <td>Nama barang</td>
        <td>Jumlah barang</td>
				<td>Total</td>
        <td>Gambar Barang</td>
				<td>Status</td>
				<td>Bukti Transfer</td>
        <td></td>
			</tr>
			<?php 
			$a = mysqli_query($con , "SELECT * FROM query_resi");

			while($b=mysqli_fetch_array($a)) {
			
			 ?>
			 <tr>
			 	<td><?php echo @$b['nama']; ?></td>
        <td><?php echo @$b['alamat']; ?></td>
			 	<td><?php echo @$b['kode_penjualan']; ?></td>
        <td><?php echo @$b['nama_barang']; ?></td>
        <td><?php echo @$b['jumlah']; ?></td>
			 	<td><?php echo @$b['total']; ?></td>
        <td><img style="width: 100px;height: 100px;" src="../gambar/<?php echo $b['gambar']; ?>"></td>

        <td><?php echo @$b['status']; ?></td>
        <td><img style="width: 100px;height: 100px;" src="../gambar/struk/<?php echo $b['bukti']; ?>"></td>
			 	<td><a href="?menu=redirect&nama=<?php echo @$b['nama'] ?>
			 		&kode_penjualan=<?php echo @$b['kode_penjualan'] ?>
			 		&total=<?php echo @$b['total'] ?>">PILIH</a></td>
			 </tr>
			 <?php } ?>
		</table>
		</div>
	</div>
</div>
<div id="copyright">
        <div class="container">
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
        </div>
    </div>  
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="../js/custom.js"></script>
</body>
</html>