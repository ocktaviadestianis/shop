<?php 
include 'config/koneksi.php';
include 'library/oop.php'; 
$perintah = new oop();
$kode ="";
session_start();
 if ($_SESSION['login'] == false) {
     echo "<script>alert('login dulu bro');document.location.href='login.php'</script>";
 }
if (@$_GET['act']=="add") {
    $kode = $_GET['kd_barang'];
    $cek =mysqli_query($con,"select * from barang where kd_barang = '$kode'");
    $data = mysqli_fetch_array($cek);
    $query = mysqli_query($con,"INSERT INTO `tmp_barang` (`nama_barang`, `satuan`, `harga_barang`, `sub_total`, `id_user`, `id_barang`) VALUES ('$data[nama_barang]', '1', '$data[harga_barang]', '', '$_SESSION[id]', '$_GET[kd_barang]');");
    if ($query) {
        ?>
         <script type="text/javascript">alert("success");window.location.href="<?php echo 'detailproduk.php?kd_barang='.$kode?>"</script>
        <?php
    }else{
        echo mysqli_error($con);
    }
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Eithree Shop</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="logo span3"><br>
                    <a class="brand" ><h2>EITHREE SHOP</h2></a>
				</div>
				<div class="span9">
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			          		</a>
			          		<div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li class=""><a href="halaman.php">Home</a></li>
                                    <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">Kategori <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            
          <?php $sql = mysqli_query($con , "SELECT * FROM Kategori"); 
            foreach ($sql as $field) {
          ?>
          <li ><a href="tampilbarang.php?id=<?php echo $field['kd_kategori'] ?>"><?php echo $field['kategori']; ?></a></li>
          <?php } ?>
                 
                                            
                                        </ul></li>
									<li><a href="testimoni.php">Testimoni</a></li>
                                    <li><a href="detailproduk.php">Keranjang</a></li>
			              			<li><a href="logout.php">Logout</a></li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
				</div>	
			</div>
		</div>
	</header>
        <!-- start: Container -->
        <div class="container">

            <!-- start: Table -->
            <div class="title"><h3>Detail Keranjang Belanja</h3></div>
<table class="table table-hover table-condensed">
<tr
                    <th><center>No</center></th>
                    <th><center>Kode Barang</center></th>
                    <th><center>Nama Barang</center></th>
                    <th><center>Harga Satuan</center></th>
                    <th><center>Jumlah Barang</center></th>
                    <th><center>Sub Total</center></th>
                    <th><center>Opsi</center></th>
                </tr>
                <?php
                //MENAMPILKAN DETAIL KERANJANG BELANJA//
                
    $total = 0;
    //mysql_select_db($database_conn, $conn);
    if (isset($_SESSION['items'])) {

        foreach ($_SESSION['items'] as $key => $val) {
            $query = mysqli_query($con, "keranjang");
            $isi = [];
            while($data = mysqli_fetch_array($query)){
                $isi[] = $data;
            // $sql=mysqli_query($con,"SELECT SUM(satuan) AS total_satuan from tmp_barang where kd_barang='$_GET[kd_barang]' and id_user='$_GET[id_user]'");
            // $dati=mysqli_fetch_array($sql);
            // echo $dati['total_satuan'];
            $jumlah_harga = $data['harga_barang'] * $data['total_satuan'];
            $total = $jumlah_harga;
            $no = 1;
            ?>
                <tr>
                <td><center><?php echo $no++; ?></center></td>
                <td><center><?php echo $isi['kd_barang']; ?></center></td>
                <td><center><?php echo $isi['nama_barang']; ?></center></td>
                <td><center><?php echo "Rp. ".number_format($data['harga_barang']); ?></center></td>

                <td><center><?php echo "Rp. ".number_format($data['satuan']); ?></center></td>
                <td><center><?php echo "Rp. ".number_format($jumlah_harga); ?></center></td>
                <td><center><a href="detail.php?act=plus&amp;kd_barang=<?php echo $key; ?>&amp;ref=detail.php" class="btn btn-xs btn-success">Tambah</a> <a href="detail.php?act=min&amp;kd_barang=<?php echo $key; ?>&amp;ref=detail.php" class="btn btn-xs btn-warning">Kurang</a> <a href="detail.php?act=del&amp;kd_barang=<?php echo $key; ?>&amp;ref=detail.php" class="btn btn-xs btn-danger">Hapus</a></center></td>
                </tr>
                
                <?php }?>
                <?php }?>
                <?php }?> 
                
                
                <!-- <?php if($total == 0){ 
                    echo '<tr><td colspan="5" align="center">Ups, Keranjang kosong!</td></tr></table>';
                    echo '<p><div align="right">
                        <a href="index.php" class="btn btn-info btn-lg">&laquo; Continue Shopping</a>
                        </div></p>';
                } else {
                    echo '
                        <tr style="background-color: #DDD;"><td colspan="4" align="right"><b>Total :</b></td><td align="right"><b>Rp. '.number_format($total,2,",",".").'</b></td></td></td><td></td></tr></table>
                        <p><div align="right">
                        <a href="index.php" class="btn btn-info">&laquo; CONTINUE SHOPPING</a>
                        <a href="checkout.php?total='.$total.'" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart icon-white"></i> CHECK OUT &raquo;</a>
                        </div></p>
                    ';
                }
                ?> -->

</table>
            
                
            <!-- end: Table -->

        </div>
    <div id="footer">
        
        <!-- start: Container -->
        <div class="container">
            
            <!-- start: Row -->
            <div class="row">

                <!-- start: About -->
                <div class="span3">
                    
                    <h3>Tentang Eithree Shop</h3>
                    <p>
                        Eithree Shop adalah toko online dengan segala jenis kategori dan sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa.
                    </p>
                        
                </div>
                <!-- end: About -->

                <!-- start: Photo Stream -->
                <div class="span3">
                    
                    <h3>Alamat Kami</h3>
                    
                </div>
                <!-- end: Photo Stream -->

                <div class="span6">
                
                    <!-- start: Follow Us -->
                    <h3>Follow Us!</h3>
                    <ul class="social-grid">
                        <li>
                            <div class="social-item">               
                                <div class="social-info-wrap">
                                    <div class="social-info">
                                        <div class="social-info-front social-twitter">
                                            <a href="http://twitter.com"></a>
                                        </div>
                                        <div class="social-info-back social-twitter-hover">
                                            <a href="http://twitter.com"></a>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="social-item">               
                                <div class="social-info-wrap">
                                    <div class="social-info">
                                        <div class="social-info-front social-facebook">
                                            <a href="http://facebook.com"></a>
                                        </div>
                                        <div class="social-info-back social-facebook-hover">
                                            <a href="http://facebook.com"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        
                    </ul>
                </div>
                
            </div>
            <!-- end: Row -->   
            
        </div>
        <!-- end: Container  -->

    </div>
    <!-- end: Footer -->

    <!-- start: Copyright -->
    <div id="copyright">
    
        <!-- start: Container -->
        <div class="container">
        
            <p>
                Copyright &copy; <a href="">Eithree Shop</a> 
            </p>
    
        </div>
        <!-- end: Container  -->
        
    </div>  
    <!-- end: Copyright -->

<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>